# RentRewards – Clickable HTML Prototype (v6)

**What’s new in v6**
- **Tenant wizard** now includes a **Review** step (auto‑generated summary) before submit.
- **Consent session state** persisted (localStorage): `awaiting` ↔ `verified`; submit requires **verified**.
- **Field masking**: PAN auto‑uppercase; Aadhaar auto‑spacing `XXXX XXXX XXXX` while storing raw digits for validation; **file previews** for landlord PAN / rent agreement.
- **Fintech hub deep mocks**: Electricity (provider list + fetch bill + pay), Credit Card (fetch bill), Mobile Recharge (plans). Extensible modal component.
- **Accessibility**: modal dialogs with **role/aria**, **keyboard focus trap**, **ESC to close**, labelled controls, skip‑link.
- **Consistent SVG iconography** (no emojis) across lists and sections.
- **More screen** gets **Recent Payments & Investments** section for extra fintech cred.

**Run**: unzip and open `index.html` in a modern browser. Toggle **Theme** and **City** from header. Use bottom nav for Home / Rewards / Scan / Shop / More.
