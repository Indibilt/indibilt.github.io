
(function(){
  const root=document.documentElement;
  const qs=(s,sc)=> (sc||document).querySelector(s);
  const qsa=(s,sc)=> Array.from((sc||document).querySelectorAll(s));

  // Theme & City toggles
  const themeBtn=qs('#themeToggle'); if(themeBtn){themeBtn.addEventListener('click',()=>{const cur=root.getAttribute('data-theme')||'dark';root.setAttribute('data-theme',cur==='dark'?'light':'dark');});}
  const cityBtn=qs('#cityToggle'); const cities=['BLR','NCR','MUM']; if(cityBtn){let i=0;root.setAttribute('data-city',cities[i]);cityBtn.innerText=cities[i];cityBtn.addEventListener('click',()=>{i=(i+1)%cities.length;root.setAttribute('data-city',cities[i]);cityBtn.innerText=cities[i];});}

  // ---------- Modal A11y: open/close, ESC, focus trap ----------
  let lastFocused=null; let trapHandler=null;
  function getFocusable(container){return qsa('a[href],button,textarea,input,select,[tabindex]:not([tabindex="-1"])', container).filter(el=>!el.disabled && el.offsetParent!==null);}
  function openModal(id){const m=qs('#'+id); if(!m) return; lastFocused=document.activeElement; m.style.display='flex'; const sheet=m.querySelector('.sheet'); const focusables=getFocusable(sheet); (focusables[0]||sheet).focus();
    const keyHandler=(e)=>{if(e.key==='Escape'){closeModal(m);} if(e.key==='Tab'){ const list=getFocusable(sheet); if(list.length===0) return; const first=list[0], last=list[list.length-1]; if(e.shiftKey && document.activeElement===first){e.preventDefault(); last.focus();} else if(!e.shiftKey && document.activeElement===last){e.preventDefault(); first.focus();}}};
    trapHandler=keyHandler; document.addEventListener('keydown', keyHandler);
  }
  function closeModal(m){ m.style.display='none'; if(trapHandler){document.removeEventListener('keydown', trapHandler); trapHandler=null;} if(lastFocused) lastFocused.focus(); }
  qsa('[data-close]').forEach(x=>x.addEventListener('click',e=>{const m=e.target.closest('.modal'); if(m) closeModal(m);}));

  // ---------- Rewards redeem ----------
  const confirm=qs('#confirmRedeem'); if(confirm){confirm.addEventListener('click',()=>{const modal=qs('#redeemModal');const sel=modal.querySelector('[data-pts].primary');const pts=sel?sel.getAttribute('data-pts'):'1000';const pv=qs('#pointsVal');if(pv){const nv=Math.max(0,(parseInt(pv.innerText.replace(/,/g,''))||0)-parseInt(pts));pv.innerText=nv.toLocaleString();}closeModal(qs('#redeemModal'));});qsa('#redeemModal [data-pts]').forEach(b=>b.addEventListener('click',()=>{qsa('#redeemModal [data-pts]').forEach(x=>x.classList.remove('primary'));b.classList.add('primary');}));}

  // ---------- Offer modal ----------
  qsa('[data-open]').forEach(b=>b.addEventListener('click',()=>{
    const id=b.getAttribute('data-open'); if(!id) return; const m=qs('#'+id); if(!m) return; m.style.display='flex';
    if(id==='offerModal'){const data=(b.getAttribute('data-offer')||'Offer|Details|Items').split('|'); qs('#offerTitle').innerText=data[0]; qs('#offerSubtitle').innerText=data[1]; const items=(data[2]||'').split(','); const list=qs('#offerItems'); if(list){list.innerHTML=''; items.forEach(it=>{const d=document.createElement('div'); d.className='item'; d.innerHTML='<div class=icon><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3" stroke="currentColor"/></svg></div><div style=flex:1><div class=title>'+it.trim()+'</div><div class=small>Included</div></div>'; list.appendChild(d);});}}
    if(id==='ftModal'){ buildFintechBody(b.getAttribute('data-ft')); }
  }));
  const act=qs('#activateOffer'); if(act){act.addEventListener('click',()=>{alert('Offer activated'); closeModal(qs('#offerModal'));});}

  // ---------- Scan ----------
  const show=qs('#showMyQR'); const myQR=qs('#myQR'); if(show&&myQR){show.addEventListener('click',()=>openModal('myQR'));}
  const simulate=qs('#simulateScan'); if(simulate){simulate.addEventListener('click',()=>{alert('QR detected • UPI collect request created');});}

  // ---------- Employer link ----------
  const link=qs('#linkEmployer'); if(link){link.addEventListener('click',()=>{const code=qs('#onboardCode')?.value?.trim(); if(!code) return alert('Enter onboarding code'); openModal('employerModal');});}

  // ---------- Sign up generic submits ----------
  const lForm=qs('#landlordForm'); if(lForm){lForm.addEventListener('submit',(e)=>{e.preventDefault(); openModal('signupDone');});}
  const sForm=qs('#storeForm'); if(sForm){sForm.addEventListener('submit',(e)=>{e.preventDefault(); openModal('signupDone');});}

  // ---------- Tenant wizard with masking, previews, review, consent state ----------
  const wizard=qs('#tenantWizard');
  if(wizard){
    const panes=qsa('.step-pane', wizard);
    const steps=qsa('#tenantStepper .step');
    const prog=qs('#tenantProg');
    let i=0; // index of step (0-based)

    function showStep(idx){ i=idx; panes.forEach((p,k)=>{p.style.display = (k===idx)?'block':'none';}); steps.forEach((s,k)=>{s.classList.toggle('active', k<=idx);}); if(prog){ prog.style.width = ((idx)/(panes.length-1))*100 + '%'; }
      qs('#tenantBack').style.display = (idx>0)?'inline-flex':'none';
      qs('#tenantNext').style.display = (idx<panes.length-1)?'inline-flex':'none';
      qs('#tenantSubmit').style.display = (idx===panes.length-1)?'inline-flex':'none';
      if(idx===panes.length-1){ renderReview(); }
    }

    function validateStep(idx){ const pane=panes[idx]; const required=qsa('[required]', pane);
      for(const el of required){ if(el.type==='checkbox'){ if(!el.checked) return false; } else if(el.type==='file'){ if(!el.files || el.files.length===0) return false; } else if(!el.value?.trim()){ return false; } else if(el.pattern){ const re=new RegExp(el.pattern); const val=el.getAttribute('data-raw')||el.value; if(!re.test(val.trim())) return false; } }
      return true; }

    // Masking: Aadhaar spacing and PAN uppercase
    const aadhaar=qs('#t_aadhaar'); if(aadhaar){ aadhaar.addEventListener('input', ()=>{
      const raw=aadhaar.value.replace(/\D/g,'').slice(0,12); aadhaar.setAttribute('data-raw', raw);
      const spaced=raw.replace(/(\d{4})(?=\d)/g,'$1 ').trim(); aadhaar.value=spaced; }); }
    const pan=qs('#t_pan'); if(pan){ pan.addEventListener('input', ()=>{ pan.value = pan.value.toUpperCase(); }); }

    // File previews
    function filePreview(input, container){ const c=qs(container); if(!c||!input) return; c.innerHTML=''; const f=input.files && input.files[0]; if(!f) return; const isImg=/image\//.test(f.type); const isPdf=f.type==='application/pdf' || f.name.toLowerCase().endsWith('.pdf'); const wrap=document.createElement('div'); wrap.className='preview'; const thumb=document.createElement('div'); thumb.className='thumb'; if(isImg){ const url=URL.createObjectURL(f); thumb.style.backgroundImage=`url(${url})`; thumb.setAttribute('aria-label','Image preview'); } else { thumb.textContent = isPdf? 'PDF' : 'FILE'; }
      const meta=document.createElement('div'); meta.className='meta'; meta.textContent = f.name + ' · ' + Math.round(f.size/1024) + ' KB'; wrap.appendChild(thumb); wrap.appendChild(meta); c.appendChild(wrap); }
    const ag=qs('#rent_agreement'); if(ag){ ag.addEventListener('change', ()=> filePreview(ag, '#agreement_preview') ); }
    const llpf=qs('#ll_pan_file'); if(llpf){ llpf.addEventListener('change', ()=> filePreview(llpf, '#ll_pan_preview') ); }

    // Consent state persistence
    const CONSENT_KEY='rr_ll_consent_status';
    const consentHidden=qs('#llConsent');
    const otpInput=qs('#llOtp');
    const manualChk=qs('#llConsentManual');
    const sendOTP=qs('#sendConsentOTP'); const sendLink=qs('#sendConsentLink');
    const verifyBtn=qs('#verifyConsent'); const stateEl=qs('#consentState');

    function updateConsentStateUI(){ const st=localStorage.getItem(CONSENT_KEY)||'none'; if(stateEl){ stateEl.textContent = 'Consent status: '+ st; } if(st==='verified'){ if(consentHidden) consentHidden.value='true'; if(manualChk) manualChk.checked=true; }
    }
    updateConsentStateUI();

    if(sendOTP){ sendOTP.addEventListener('click', ()=>{ localStorage.setItem(CONSENT_KEY,'awaiting'); updateConsentStateUI(); openModal('consentSent'); }); }
    if(sendLink){ sendLink.addEventListener('click', ()=>{ localStorage.setItem(CONSENT_KEY,'awaiting'); updateConsentStateUI(); openModal('consentSent'); }); }
    if(manualChk){ manualChk.addEventListener('change', ()=>{ if(manualChk.checked){ localStorage.setItem(CONSENT_KEY,'verified'); if(consentHidden) consentHidden.value='true'; } else { localStorage.setItem(CONSENT_KEY,'awaiting'); if(consentHidden) consentHidden.value='false'; } updateConsentStateUI(); }); }
    if(verifyBtn){ verifyBtn.addEventListener('click', ()=>{ if((otpInput?.value||'').trim().length===6){ localStorage.setItem(CONSENT_KEY,'verified'); if(consentHidden) consentHidden.value='true'; alert('Consent verified via OTP'); updateConsentStateUI(); } else { alert('Enter valid 6‑digit OTP'); } }); }

    // Review render
    function maskAadhaarDisplay(raw){ if(!raw) return ''; return raw.replace(/\D/g,'').replace(/.(?=.{4})/g,'•').replace(/(\d{4})(?=\d)/g,'$1 '); }
    function renderReview(){ const list=qs('#reviewList'); if(!list) return; list.innerHTML='';
      const data={
        name: qs('#t_name')?.value||'', address: qs('#t_addr')?.value||'', aadhaar: qs('#t_aadhaar')?.getAttribute('data-raw')||'', pan: qs('#t_pan')?.value||'', phone: qs('#t_phone')?.value||'', email: qs('#t_email')?.value||'',
        ll_name: qs('#ll_name')?.value||'', ll_contact: qs('#ll_contact')?.value||'', ll_email: qs('#ll_email')?.value||'', consent: localStorage.getItem(CONSENT_KEY)||'none'
      };
      const rows=[
        ['Name', data.name],
        ['Address', data.address],
        ['Aadhaar', maskAadhaarDisplay(data.aadhaar)],
        ['PAN', data.pan],
        ['Contact', data.phone],
        ['Email', data.email],
        ['Landlord Name', data.ll_name],
        ['Landlord Contact', data.ll_contact],
        ['Landlord Email', data.ll_email],
        ['Consent', data.consent]
      ];
      rows.forEach(([k,v])=>{ const d=document.createElement('div'); d.className='item'; d.innerHTML=`<div class='icon'><svg viewBox='0 0 24 24'><path d='M4 12h16' stroke='currentColor'/></svg></div><div style='flex:1'><div class='title'>${k}</div><div class='small'>${(v||'—')}</div></div>`; list.appendChild(d); });
    }

    // Buttons
    qs('#tenantBack').addEventListener('click', ()=> showStep(Math.max(0, i-1)));
    qs('#tenantNext').addEventListener('click', ()=>{ if(!validateStep(i)) return alert('Please complete required fields in this step'); showStep(Math.min(panes.length-1, i+1)); });
    wizard.addEventListener('submit', (e)=>{ e.preventDefault(); if(!validateStep(i)) return alert('Please complete required fields'); if((localStorage.getItem(CONSENT_KEY)||'none')!=='verified') return alert('Landlord KYC consent is required'); openModal('signupDone'); });

    showStep(0);
  }

  // ---------- Fintech deep mocks ----------
  function buildFintechBody(type){ const body=qs('#ftBody'); if(!body) return; body.innerHTML='';
    if(type==='electricity'){
      body.innerHTML = `
        <div class='form'>
          <label for='prov'>Provider</label>
          <select id='prov'><option value='BESCOM'>BESCOM</option><option value='MSEDCL'>MSEDCL</option><option value='BSES'>BSES</option></select>
          <label for='cid'>Consumer ID</label>
          <input id='cid' placeholder='e.g., 1234567890'>
          <div class='cta mt-12'><button class='btn primary' id='fetchBill'>Fetch Bill</button></div>
          <div id='billArea' class='list mt-12' aria-live='polite'></div>
        </div>`;
      qs('#fetchBill').addEventListener('click', ()=>{
        const provider=qs('#prov').value; const cid=qs('#cid').value.trim(); if(!cid) return alert('Enter Consumer ID');
        const due='Oct 05'; const amt=(1200+Math.floor(Math.random()*600));
        qs('#billArea').innerHTML = `<div class='item'><div class='icon'>{svg('bolt')}</div><div style='flex:1'><div class='title'>${provider} · ${cid}</div><div class='small'>Due ${due}</div></div><span class='chip'>₹${amt}</span></div><div class='cta mt-12'><button class='btn success'>Pay ₹${amt}</button></div>`;
      });
    } else if(type==='ccbill'){
      body.innerHTML = `
        <div class='form'>
          <label for='bank'>Bank</label>
          <select id='bank'><option>HDFC</option><option>ICICI</option><option>SBI</option></select>
          <label for='cardNo'>Card Number</label>
          <input id='cardNo' placeholder='XXXX XXXX XXXX 1234'>
          <div class='cta mt-12'><button class='btn primary' id='fetchCC'>Fetch Bill</button></div>
          <div id='ccArea' class='list mt-12' aria-live='polite'></div>
        </div>`;
      qs('#fetchCC').addEventListener('click', ()=>{
        const bank=qs('#bank').value; const last4=(1000+Math.floor(Math.random()*9000)); const amt=(8000+Math.floor(Math.random()*6000));
        qs('#ccArea').innerHTML = `<div class='item'><div class='icon'>{svg('card')}</div><div style='flex:1'><div class='title'>${bank} · **** ${last4}</div><div class='small'>Statement generated</div></div><span class='chip'>₹${amt}</span></div><div class='cta mt-12'><button class='btn success'>Pay ₹${amt}</button></div>`;
      });
    } else if(type==='recharge'){
      body.innerHTML = `
        <div class='form'>
          <label for='op'>Operator</label>
          <select id='op'><option>Jio</option><option>Airtel</option><option>Vi</option></select>
          <label for='mob'>Mobile Number</label>
          <input id='mob' placeholder='10-digit number' maxlength='10'>
          <div class='cta mt-12'><button class='btn primary' id='fetchPlans'>View Plans</button></div>
          <div id='planArea' class='list mt-12' aria-live='polite'></div>
        </div>`;
      qs('#fetchPlans').addEventListener('click', ()=>{
        qs('#planArea').innerHTML = `<div class='item'><div class='icon'>{svg('recharge')}</div><div style='flex:1'><div class='title'>1.5GB/day · 28 days</div><div class='small'>Unlimited calls</div></div><span class='chip'>₹239</span></div><div class='item'><div class='icon'>{svg('recharge')}</div><div style='flex:1'><div class='title'>2GB/day · 56 days</div><div class='small'>Unlimited calls</div></div><span class='chip'>₹479</span></div>`;
      });
    } else {
      body.innerHTML = `<div class='small'>Coming soon…</div>`;
    }
    openModal('ftModal');
  }
})();
